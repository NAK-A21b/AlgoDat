package algodat;

import java.util.List;

public abstract class AbstractKnapsackTest {

	protected abstract IKnapsack create (int capacity, List<IKnapsack.Element> elements);

}
