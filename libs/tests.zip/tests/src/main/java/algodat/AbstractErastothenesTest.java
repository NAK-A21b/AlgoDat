package algodat;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public abstract class AbstractErastothenesTest {

	protected abstract IPrimeNumbers create ();

	@Test
	public void testPrime () {
		List<Integer> primeNumbers = create().primes(100);
		int[] primes100 = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97};
		assertEquals(primes100.length, primeNumbers.size());
		for (int p : primes100) {
			assertTrue (primeNumbers.contains(p));
		}
	}

}
