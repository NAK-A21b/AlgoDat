package algodat;

/**
 * This package contains abstract test cases for implementations of the interfaces provided in the "interfaces"
 * package.
 *
 * Concrete test cases will use the abstract test cases defined herein to build specialized test cases. In many
 * cases you will only have to create a specialized test class and to override a single method to create your
 * data structure / algorithm implementation.
 *
 * @author himmelspach
 */