package algodat.sorting;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Abstract class to test implementations of the {@link ISort} interface
 *
 * @author himmelspach
 */
public abstract class AbstractSortingTest {

    protected abstract algodat.sorting.ISort<Integer> createMethod ();
    
    Integer[] emptyArray = new Integer[]{};
    Integer[] singleEntryArray = new Integer[]{0};
    Integer[] twoEntryArraySorted = new Integer[]{0, 1};
    Integer[] twoEntryArrayUnSorted = new Integer[]{1, 0};
    Integer[] threeEntryArraySorted = new Integer[]{0, 1, 2};
    Integer[] threeEntryArrayUnSorted = new Integer[]{2, 0, 1};
    Integer[] multipleEntryArraySorted = new Integer[]{0, 1, 2, 3, 4, 5, 6};
    Integer[] multipleEntryArrayUnSorted = new Integer[]{1, 0, 4, 5, 2, 6, 3};
    Integer[] multipleEntryArrayUnSortedEven = new Integer[]{1, 0, 4, 5, 2, 6, 3, 7};
    Integer[] multipleEntryArrayInverted = new Integer[]{7, 6, 5, 4, 3, 2, 1, 0};
    Integer[] multipleEntryArrayUpSortedSingleFailure = new Integer[]{0, 1, 2, 4, 3, 5, 6, 7, 8, 9};

    @BeforeEach
    public void init () {
        emptyArray = new Integer[]{};
        // in place algodat.sorting algorithms will replace these
        singleEntryArray = new Integer[]{0};
        twoEntryArraySorted = new Integer[]{0, 1};
        twoEntryArrayUnSorted = new Integer[]{1, 0};
        threeEntryArraySorted = new Integer[]{0, 1, 2};
        threeEntryArrayUnSorted = new Integer[]{2, 0, 1};
        multipleEntryArraySorted = new Integer[]{0, 1, 2, 3, 4, 5, 6};
        multipleEntryArrayUnSorted = new Integer[]{1, 0, 4, 5, 2, 6, 3};
        multipleEntryArrayUnSortedEven = new Integer[]{1, 0, 4, 5, 2, 6, 3, 7};
        multipleEntryArrayInverted = new Integer[]{7, 6, 5, 4, 3, 2, 1, 0};
        multipleEntryArrayUpSortedSingleFailure = new Integer[]{0, 1, 2, 4, 3, 5, 6, 7, 8, 9};
    }


    @Test
    public void testEmpty () {
        Integer[] a = createMethod().sort(emptyArray);
        assertEquals (0, a.length);
    }

    @Test
    public void testSingleEntry () {
        Integer[] a = createMethod().sort(singleEntryArray);
        assertEquals (1, a.length);
        assertEquals (0, a[0]);
    }

    @Test
    public void testTwoEntriesSorted () {
        Integer[] a = createMethod().sort(twoEntryArraySorted);
        assertEquals (2, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testTwoEntriesUnSorted () {
        Integer[] a = createMethod().sort(twoEntryArrayUnSorted);
        assertEquals (2, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testThreeEntriesSorted () {
        Integer[] a = createMethod().sort(threeEntryArraySorted);
        assertEquals (3, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testThreeEntriesUnSorted () {
        Integer[] a = createMethod().sort(threeEntryArrayUnSorted);
        assertEquals (3, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testMultipleEntriesSorted () {
        Integer[] a = createMethod().sort(multipleEntryArraySorted);
        assertEquals (multipleEntryArraySorted.length, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2, 3, 4, 5, 6}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testMultipleEntriesUnSorted () {
        Integer[] a = createMethod().sort(multipleEntryArrayUnSorted);
        assertEquals (multipleEntryArrayUnSorted.length, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2, 3, 4, 5, 6}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testMultipleEntriesUnSortedEven () {
        Integer[] a = createMethod().sort(multipleEntryArrayUnSortedEven);
        assertEquals (multipleEntryArrayUnSortedEven.length, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2, 3, 4, 5, 6, 7}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testMultipleEntriesInverted () {
        Integer[] a = createMethod().sort(multipleEntryArrayInverted);
        assertEquals (multipleEntryArrayInverted.length, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2, 3, 4, 5, 6, 7}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testMultipleEntriesUpSortedSingleFailure () {
        Integer[] a = createMethod().sort(multipleEntryArrayUpSortedSingleFailure);
        assertEquals (multipleEntryArrayUpSortedSingleFailure.length, a.length);
        assertTrue (Arrays.compare(new Integer[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}, a) == 0, Arrays.toString(a));
    }


    @Test
    public void testLargeArray () {
        // tests larger index values, weak test case
        int n = 10000;
        Integer[] in = new Integer[n];

        for (int i = 0; i < n; i++) {
            in[i] = i;
        }

        Random ran = new Random(238643451);

        for (int i = 0; i < n/3; i++) { // swap n/3 times elements (approx 2/3 of elements swapped)
            int a = ran.nextInt(in.length);
            int b = ran.nextInt(in.length);

            Integer val = in[a];
            in[a] = in[b];
            in[b] = val;
        }

        Integer[] a = createMethod().sort(in);
        assertEquals (n, a.length);
        for (int i = 1; i < a.length; i++) {
            assertEquals(a[i-1]+1, a[i]);
        }
    }

}
