package algodat.sorting.special;


import algodat.sorting.ISort;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public abstract class AbstractLowMemUniqueIntSortTest {

    protected abstract ISort<Integer> createMethod();

    @Test
    public void testSimpleArray () {
        Integer[] a = createMethod().sort(new Integer[] {1,8,32,48,128 });
        assertTrue (Arrays.compare(new Integer[] {1, 8, 32, 48, 128}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testSimpleArrayUnSorted () {
        Integer[] a = createMethod().sort(new Integer[] {48,128,8,1,32, });
        assertTrue (Arrays.compare(new Integer[] {1, 8, 32, 48, 128}, a) == 0, Arrays.toString(a));
    }

    @Test
    public void testLargeArray () {
        // tests larger index values, weak test case
        int n = 950000;
        Integer[] in = new Integer[n];

        for (int i = 0; i < n; i++) {
            in[i] = i;
        }

        Random ran = new Random(238643451);

        for (int i = 0; i < n/3; i++) { // swap n/3 times elements (approx 2/3 of elements swapped)
            int a = ran.nextInt(in.length);
            int b = ran.nextInt(in.length);

            Integer val = in[a];
            in[a] = in[b];
            in[b] = val;
        }

        Integer[] a = createMethod().sort(in);
        assertEquals (n, a.length);
        for (int i = 1; i < a.length; i++) {
            assertEquals(a[i-1]+1, a[i]);
        }
    }

}
