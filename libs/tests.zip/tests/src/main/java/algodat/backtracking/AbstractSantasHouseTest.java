package algodat.backtracking;

import algodat.structure.graph.IGraph;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

public abstract class AbstractSantasHouseTest {

	List<List<ISantasHouse.Path>> hvnSimpleSolutions;
	List<List<ISantasHouse.Path>> hvnMirroredSolutions;

	protected abstract IGraph<String> createSimple ();
	protected abstract IGraph<String> createMirrored ();
	protected abstract ISantasHouse create ();

	{
		hvnSimpleSolutions = create().findSolutions(createSimple());
		hvnMirroredSolutions = create().findSolutions(createMirrored());
	}

	@Test
	public void testNumberOfResultsSimpleHouse () {
		assertEquals (88, hvnSimpleSolutions.size());
	}

	@Test
	public void testNumberOfResultsMirroredHouse () {
		assertEquals (13760, hvnMirroredSolutions.size());
	}

	@Test
	public void testDuplicatesSimpleHouse () {
		testDuplicates(hvnSimpleSolutions);
	}

	@Test
	public void testDuplicatesMirroredHouse () {
		testDuplicates(hvnMirroredSolutions);
	}

	private void testDuplicates (List<List<ISantasHouse.Path>> list) {
		for (int i = 0; i < list.size() - 1; i++) {
			for (int j = 0; j < list.size(); j++) {
				if (i != j) {
					assertFalse(compareIdent(list.get(i), list.get(j)));
				}
			}
		}
	}

	private boolean compareIdent(List<ISantasHouse.Path> path1, List<ISantasHouse.Path> path2) {
		for (int i = 0; i < path1.size(); i++) {
			if (!path1.get(i).equals(path2.get(i))) {
				return false;
			}
		}
		return true;
	}

}
