package algodat.structure.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class AbstractGraphTest {

	protected IVertex<Integer> v1;
	protected IVertex<Integer> v2;
	protected IVertex<Integer> v3;
	protected IVertex<Integer> v4;

	public IGraph<Integer> initGraph () {
		IGraph<Integer> testGraph = createGraph ();
		v1 = testGraph.addVertex(1);
		v2 = testGraph.addVertex(2);
		v3 = testGraph.addVertex(3);
		v4 = testGraph.addVertex(4);
		testGraph.addEdge(v3,v2);
		testGraph.addEdge(v1,v2);
		testGraph.addEdge(v1,v4);
		return testGraph;
	}

	public abstract IGraph<Integer> createGraph ();

	@Test
	public void testNumberOfVertices () {
		assertEquals (4, initGraph ().vertices().size());
	}

	@Test
	public void testNumberOfEdges () {
		assertEquals (3, initGraph ().edgeCount());
	}

	@Test
	public void testNeighbours () {
		assertEquals( 2, initGraph ().neighbours(v1).size());
		assertEquals( 2, initGraph ().neighbours(v2).size());
		assertEquals( 1, initGraph ().neighbours(v3).size());
		assertEquals( 1, initGraph ().neighbours(v4).size());
	}


}
