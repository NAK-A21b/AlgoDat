package algodat.structure.graph.linked.singlelinked;

import algodat.structure.IQueue;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public abstract class AbstractPriorityQueueTest {

	protected abstract IQueue<Integer> create ();

	@Test
	public void testEmptyIQueue () {
		IQueue<Integer> s = create();
		assertNull (s.front());
		assertNull (s.dequeue());
	}

	@Test
	public void testTop1IQueue () {
		IQueue<Integer> s = create();
		s.enqueue(1);
		assertEquals (1, s.front());
		assertEquals (1, s.dequeue());
		assertNull (s.front());
	}

	@Test
	public void testTop2IQueue () {
		IQueue<Integer> s = create();
		s.enqueue(1);
		s.enqueue(2);
		assertEquals (1, s.front());
		assertEquals (1, s.dequeue());
		assertEquals (2, s.front());
		assertEquals (2, s.dequeue());
		assertNull(s.front());
	}

	@Test
	public void testTop3IQueue () {
		IQueue<Integer> s = create();
		s.enqueue(1);
		s.enqueue(2);
		assertEquals (1, s.front());
		assertEquals (1, s.dequeue());
		s.enqueue(3);
		assertEquals (2, s.front());
		assertEquals (2, s.dequeue());
	}

	@Test
	public void testUnsortedIQueue () {
		IQueue<Integer> s = create();
		s.enqueue(3);
		s.enqueue(1);
		assertEquals (1, s.front());
		assertEquals (1, s.dequeue());
		s.enqueue(2);
		assertEquals (2, s.front());
		assertEquals (2, s.dequeue());
	}

}
