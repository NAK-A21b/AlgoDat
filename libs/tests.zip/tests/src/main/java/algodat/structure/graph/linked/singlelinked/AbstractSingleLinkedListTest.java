package algodat.structure.graph.linked.singlelinked;

import algodat.structure.IList;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public abstract class AbstractSingleLinkedListTest {

	protected abstract IList<Integer> create ();

	@Test
	public void testEmpty () {
		IList<Integer> s = create();
		assertNull (s.get(0));
		assertEquals(0, s.size());
	}

	@Test
	public void testSingleEntry () {
		IList<Integer> s = create();
		s.add(1);
		assertEquals (1, s.get(0));
		assertEquals(1, s.size());
	}

	@Test
	public void testAdd () {
		IList<Integer> s = create();
		s.add(1);
		s.add(2);
		s.add(0);
		s.add(3);
		assertEquals(4, s.size());
	}

	@Test
	public void test2Entries () {
		IList<Integer> s = create();
		s.add(1);
		s.add(2);
		assertEquals (1, s.get(0));
		assertEquals (2, s.get(1));
		assertEquals(2, s.size());
	}

	@Test
	public void testDelete () {
		IList<Integer> s = create();
		s.add(1);
		s.add(2);
		s.delete(0);
		assertEquals (2, s.get(0));
		assertEquals(1, s.size());
	}

	@Test
	public void testDelete2 () {
		IList<Integer> s = create();
		s.add(1);
		s.add(2);
		s.delete(1);
		assertEquals (1, s.get(0));
		assertEquals(1, s.size());
	}

	@Test
	public void testDelete3 () {
		IList<Integer> s = create();
		s.add(1);
		s.add(2);
		s.add(3);
		s.delete(1);
		assertEquals (1, s.get(0));
		assertEquals (3, s.get(1));
		assertEquals(2, s.size());
	}

	@Test
	public void testDelete4 () {
		IList<Integer> s = create();
		s.add(1);
		s.add(2);
		s.add(3);
		s.delete(1);
		s.add(2);
		s.delete(1);
		assertEquals (1, s.get(0));
		assertEquals (2, s.get(1));
		assertEquals(2, s.size());
	}

}
