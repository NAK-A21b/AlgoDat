package algodat.structure.graph.linked.singlelinked;

import algodat.structure.IStack;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public abstract class AbstractStackTest {

	protected abstract IStack<Integer> create ();

	@Test
	public void testEmptyStack () {
		IStack<Integer> s = create();
		assertNull (s.top());
		assertNull (s.pop());
	}

	@Test
	public void testTop1Stack () {
		IStack<Integer> s = create();
		s.push(1);
		assertEquals (1, s.top());
		assertEquals (1, s.pop());
		assertNull (s.top());
	}

	@Test
	public void testTop2Stack () {
		IStack<Integer> s = create();
		s.push(1);
		s.push(2);
		assertEquals (2, s.top());
		assertEquals (2, s.pop());
		assertEquals (1, s.top());
		assertEquals (1, s.pop());
		assertNull(s.top());
	}

	@Test
	public void testTop3Stack () {
		IStack<Integer> s = create();
		s.push(1);
		s.push(2);
		assertEquals (2, s.top());
		assertEquals (2, s.pop());
		s.push(3);
		assertEquals (3, s.top());
		assertEquals (3, s.pop());
	}

}
