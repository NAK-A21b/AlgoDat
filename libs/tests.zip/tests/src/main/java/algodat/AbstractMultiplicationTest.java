package algodat;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class AbstractMultiplicationTest {

	protected abstract IMultiplication create ();

	@Test
	public void testMultZero () {
		assertEquals (0, create().multiply(0, 2));
		assertEquals (0, create().multiply(2, 0));
	}

	@Test
	public void testMultOne () {
		assertEquals (2, create().multiply(1, 2));
		assertEquals (2, create().multiply(2, 1));
	}

	@Test
	public void testMult () {
		assertEquals (8, create().multiply(4, 2));
		assertEquals (27, create().multiply(3, 9));
	}

}
