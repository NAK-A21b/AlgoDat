package algodat;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class AbstractSearchStringTest {

	protected abstract ISearchString create();

	@Test
	public void testExistent1() {
		assertEquals(15, create().stringMatch("10010101101001100101111010", "001011"));
	}

	@Test
	public void testNonExistent1() {
		assertEquals(-1, create().stringMatch("10010101101001100101011010", "001011"));
	}

	@Test
	public void testExistent2() {
		assertEquals(31, create().stringMatch("It is never too late to have a happy childhood.", "happy"));
	}

	@Test
	public void testNonExistent2() {
		assertEquals(-1, create().stringMatch("It is never too late to have a happy childhood.", "happier"));
	}

}
