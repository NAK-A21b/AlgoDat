package algodat;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class AbstractFibonacciTest {

	protected abstract IFibonacci create ();

	IFibonacci fibonacci = create();

	@Test
	public void testFib0 () {
		assertEquals (0, fibonacci.fib(0));
	}

	@Test
	public void testFib1 () {
		assertEquals (1, fibonacci.fib(1));
	}

	@Test
	public void testFib2 () {
		assertEquals (1, fibonacci.fib(2));
	}

	@Test
	public void testFib3 () {
		assertEquals (2, fibonacci.fib(3));
	}

	@Test
	public void testFib8 () {
		assertEquals (21, fibonacci.fib(8));
	}
}
