package algodat.searching;

import algodat.backtracking.ISantasHouse;
import algodat.structure.graph.IGraph;
import algodat.structure.graph.IVertex;
import algodat.structure.graph.IVisitor;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class AbstractGraphSearchTest {

	protected abstract IGraphSearch create ();
	protected abstract IGraph createGraph ();

	@Test
	public void testHVNSimple() {
		IGraph<String> simpleHouse = ISantasHouse.createSimpleHouse(createGraph());
		Map map = create().search(simpleHouse, simpleHouse.vertices().get(0), new IVisitor() {
			@Override
			public boolean visit(IVertex v) {
				return false;
			}
		});
		assertEquals(5, map.size());
	}

	@Test
	public void testHVNMirrored() {
		IGraph<String> mirroredHouse = ISantasHouse.createMirroredHouse(createGraph());
		Map map = create().search(mirroredHouse, mirroredHouse.vertices().get(0), new IVisitor() {
			@Override
			public boolean visit(IVertex v) {
				return false;
			}
		});
		assertEquals(8, map.size());
	}


}
