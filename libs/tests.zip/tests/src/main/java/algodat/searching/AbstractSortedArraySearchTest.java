package algodat.searching;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public abstract class AbstractSortedArraySearchTest {

	protected abstract ISearch<Integer> searchMethod ();

	@Test
	public void testSearchEmpty () {
		Assertions.assertEquals (-1, searchMethod().search(1, new Integer[] {}));
	}

	@Test
	public void testSearchSingleEntryExisting () {
		Assertions.assertEquals (0, searchMethod().search(1, new Integer[] {1}));
	}

	@Test
	public void testSearchSingleEntryNotExisting () {
		Assertions.assertEquals (-1, searchMethod().search(1, new Integer[] {2}));
	}

	@Test
	public void testSearchTwoEntriesNotExisting () {
		Assertions.assertEquals (-1, searchMethod().search(1, new Integer[] {2, 3}));
	}

	@Test
	public void testSearchTwoEntriesExisting1 () {
		Assertions.assertEquals (0, searchMethod().search(1, new Integer[] {1, 3}));
	}

	@Test
	public void testSearchTwoEntriesExisting2 () {
		Assertions.assertEquals (1, searchMethod().search(3, new Integer[] {1, 3}));
	}

	@Test
	public void testSearchMultipleEntriesNotExisting () {
		Assertions.assertEquals (-1, searchMethod().search(5, new Integer[] {1, 2, 3, 4}));
	}

	@Test
	public void testSearchMultipleEntriesExisting1 () {
		Assertions.assertEquals (0, searchMethod().search(1, new Integer[] {1, 2, 3, 4}));
	}

	@Test
	public void testSearchMultipleEntriesExisting2 () {
		Assertions.assertEquals (2, searchMethod().search(3, new Integer[] {1, 2, 3, 4}));
	}

	@Test
	public void testSearchMultipleEntriesExisting3 () {
		Assertions.assertEquals (3, searchMethod().search(4, new Integer[] {1, 2, 3, 4}));
	}

}
