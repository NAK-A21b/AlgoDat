package algodat.searching;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public abstract class AbstractLinearSearchTest {

	protected abstract ISearch<Integer> create ();

	@Test
	public void testEmpty () {
		Integer[] a = new Integer[] {};
		assertTrue (create().search(1, a) == -1);
	}

	@Test
	public void testSingleEntryExisting () {
		Integer[] a = new Integer[] {1};
		assertTrue (create().search(1, a) == 0);
	}

	@Test
	public void testSingleEntryNotExisting () {
		Integer[] a = new Integer[] {1};
		assertTrue (create().search(2, a) == -1);
	}

	@Test
	public void testTwoEntriesExisting () {
		Integer[] a = new Integer[] {1, 2};
		assertTrue (create().search(1, a) == 0);
		assertTrue (create().search(2, a) == 1);
	}

	@Test
	public void testTwoEntriesNotExisting () {
		Integer[] a = new Integer[] {1, 2};
		assertTrue (create().search(3, a) == -1);
		assertTrue (create().search(0, a) == -1);
	}

}
