package algodat.searching;

import algodat.structure.tree.binary.IBinaryTree;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public abstract class AbstractBinaryTreeSearchTest {

	protected abstract  IBinaryTree<Integer> createBinaryTree();

	protected abstract IBinaryTreeSearch<Integer> create ();

	@Test
	public void testEmptyBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		assertFalse (create().hasValue(1, tree));
	}

	@Test
	public void testSingleEntryInBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		tree.addValue(1);
		assertTrue (create().hasValue(1, tree));
	}

	@Test
	public void testSingleEntryNotInBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		tree.addValue(2);
		assertFalse (create().hasValue(1, tree));
	}

	@Test
	public void testSplitEntryInBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		tree.addValue(1);
		tree.addValue(0);
		tree.addValue(2);
		assertTrue (create().hasValue(0, tree));
		assertTrue (create().hasValue(1, tree));
		assertTrue (create().hasValue(2, tree));
	}

	@Test
	public void testSplitEntryNotInBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		tree.addValue(1);
		tree.addValue(0);
		tree.addValue(2);
		assertFalse (create().hasValue(3, tree));
	}

	@Test
	public void testDoubleSplitEntryInBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		tree.addValue(5);
		tree.addValue(3);
		tree.addValue(4);
		tree.addValue(2);
		tree.addValue(7);
		tree.addValue(6);
		tree.addValue(8);
		assertTrue (create().hasValue(7, tree));
		assertTrue (create().hasValue(8, tree));
		assertTrue (create().hasValue(2, tree));
		assertTrue (create().hasValue(3, tree));
		assertTrue (create().hasValue(4, tree));
		assertTrue (create().hasValue(5, tree));
		assertTrue (create().hasValue(6, tree));
	}

	@Test
	public void testDoubleSplitEntryNotInBinaryTree () {
		IBinaryTree<Integer> tree = createBinaryTree();
		tree.addValue(5);
		tree.addValue(3);
		tree.addValue(4);
		tree.addValue(2);
		tree.addValue(7);
		tree.addValue(6);
		tree.addValue(8);
		assertFalse (create().hasValue(1, tree));
	}

}
