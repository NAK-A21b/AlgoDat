package algodat;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class AbstractClosestPointTest {

    protected abstract IClosestPoints create ();

    @Test
    public void minimalList () {
        List<IClosestPoints.Point> list = new ArrayList<>();
        list.add(new IClosestPoints.Point(1,1));
        list.add(new IClosestPoints.Point(1,2));

        IClosestPoints.Point index = create().find(list);
        assertEquals (0, index.getX());
        assertEquals (1, index.getY());
    }

    @Test
    public void minimum () {
        List<IClosestPoints.Point> list = new ArrayList<>();
        list.add(new IClosestPoints.Point(1,1));
        list.add(new IClosestPoints.Point(2,3));
        list.add(new IClosestPoints.Point(5,7));
        list.add(new IClosestPoints.Point(2,1));
        list.add(new IClosestPoints.Point(6,10));

        IClosestPoints.Point index = create().find(list);
        assertEquals (0, index.getX());
        assertEquals (3, index.getY());
    }

}
