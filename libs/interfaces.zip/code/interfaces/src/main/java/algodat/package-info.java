package algodat;

/**
 * The package algodat contains interfaces for diverse data structures and algorithms.
 *
 * For exercise: provide implementations of the interfaces, test your implementations using the algodat-tests abstract
 * test cases.
 *
 * @author himmelspach
 */