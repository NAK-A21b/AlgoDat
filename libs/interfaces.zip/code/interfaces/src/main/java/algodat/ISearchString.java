package algodat;

/**
 * String pattern search interface.
 *
 * @author himmelspach
 */
public interface ISearchString {

	/**
	 * Finds the index of the pattern in the text.
	 * @param text - the text to search the pattern in
	 * @param pattern - the pattern to search for in the text
	 * @return index of pattern or -1 if the pattern is not contained in text
	 */
	int stringMatch(String text, String pattern);

}
