package algodat;

public interface IMultiplication {

	/**
	 * Multiplication a la Russe
	 * @param m - a positive integer
	 * @param n - a positive integer
	 * @return m multiplied with n
	 */
	long multiply (int m, int n);

}
