package algodat.structure.tree.binary;

public interface INode<V extends Comparable<V>> {

	INode getLeft();

	void setLeft(INode left);

	INode getRight();

	void setRight(INode right);

	V getValue();

	void setValue(V value);

	void addChild(INode<V> node);

	int depth();

}
