package algodat;

import java.util.List;

/**
 * The N-Dames problem.
 *
 * N-Dames have to be placed on a board of a pre-defined size without the ability of any of those to beat another
 * dame with the next move following the chess rules.
 *
 * @author himmelspach
 */
public interface INDames {

	/**
	 * Return a list of
	 * @param n - the number of dames to be placed on the board
	 * @return a list of boards containing the conflict free solution of the positions of the n dames
	 */
	List<boolean[][]> findSolutions (int n);

}
