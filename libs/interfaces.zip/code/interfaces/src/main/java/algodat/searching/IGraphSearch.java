package algodat.searching;

import algodat.structure.graph.IGraph;
import algodat.structure.graph.IVertex;
import algodat.structure.graph.IVisitor;

import java.util.Map;

public interface IGraphSearch<E> {

	Map<Integer, IVertex<E>> search (IGraph<E> graph, IVertex<E> start, IVisitor<E> visitor);

}
