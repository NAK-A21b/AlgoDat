package algodat.structure;

public interface IList<E> {

	void add(E element);

	E get(int index);

	void delete(int index);

	int size();
}
