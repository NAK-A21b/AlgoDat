package algodat.searching;

/**
 * @author himmelspach
 * @param <E>
 */
public interface ISearch<E extends Comparable<E>> {

	int search (E search, E[] a);

}
