package algodat;

import java.util.List;

public interface IPrimeNumbers {

	List<Integer> primes (int n);

}
