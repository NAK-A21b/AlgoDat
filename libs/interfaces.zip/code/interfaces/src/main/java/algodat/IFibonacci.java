package algodat;

public interface IFibonacci {

	long fib(int n);

}
