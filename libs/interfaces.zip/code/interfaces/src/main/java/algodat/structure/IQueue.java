package algodat.structure;

/**
 * @author himmelspach
 * @param <E>
 */
public interface IQueue<I> {

    /**
     *
     * @param item
     */
    void enqueue(I item);

    /**
     * Entehme das erste Element der Warteschlange und gebe es zurück.
     * @return das erste Element der Warteschlange oder null, wenn es ein solches Element nicht gibt
     */
    I dequeue ();

    /**
     * Lese das erste Element der Warteschlange und gebe es zurück. Das Element verbleibt in der Queue.
     * @return das erste Element der Warteschlange oder null, wenn es ein solches Element nicht gibt
     */
    I front ();

    /**
     * Überprüfe, ob die Queue leer ist ({@link #size()} == 0.
     * @return true, wenn die Queue leer ist, false andernfalss
     */
    boolean isEmpty ();

    /**
     * Ermittelt die Anzahl der Elemente in der Warteschlange.
     * @return Die Anzahl der Elemente oder 0, wenn die Warteschlange leer ist.
     */
    int size ();

}
