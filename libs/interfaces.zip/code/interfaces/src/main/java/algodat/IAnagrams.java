package algodat;

import java.util.List;
import java.util.Set;

/**
 * Find all anagrams of a given word in a given dictionary.
 *
 * Please refer to "Programming Pearls" by Jon Bentley for task and solution.
 *
 * @author himmelspach
 */
public interface IAnagrams {

	/**
	 * Returns all those words from the dictionary whereof the letters (in any order, but same frequency) are the same
	 * as those on the word given.
	 * @param word containing letters to search anagrams of
	 * @param dictionary containing set of words to search for anagrams in
	 * @return list of words from the dictionary containing the same letters as in the word given
	 */
	List<String> find(String word, Set<String> dictionary);

}
