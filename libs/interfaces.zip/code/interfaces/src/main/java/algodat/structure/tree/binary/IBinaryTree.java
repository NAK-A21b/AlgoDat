package algodat.structure.tree.binary;

public interface IBinaryTree<E extends Comparable<E>> {

	void addValue (E value);

	boolean isEmpty ();

	INode<E> getRoot();
}
