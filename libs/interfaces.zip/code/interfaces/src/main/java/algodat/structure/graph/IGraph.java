package algodat.structure.graph;

import java.util.List;

/**
 * @author himmelspach
 * @param <E>
 */
public interface IGraph<E> {

	IVertex<E> addVertex(E value);

	void addEdge(IVertex<E> a, IVertex<E> b);

	List<IVertex<E>> neighbours(IVertex<E> a);

	List<IVertex<E>> vertices ();

	int edgeCount ();

}
