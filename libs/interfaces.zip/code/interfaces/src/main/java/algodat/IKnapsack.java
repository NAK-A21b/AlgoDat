package algodat;

import java.util.Arrays;
import java.util.Map;

public interface IKnapsack {

	class Element {
		private int weight;
		private int value;

		public Element () {

		}

		public Element (int weight, int value) {
			this.weight = weight;
			this.value = value;
		}

		public int getWeight() {
			return weight;
		}
		public int getValue() {
			return value;
		}

		@Override
		public String toString() {
			return "Element{" +
							"weight=" + weight +
							", value=" + value +
							'}';
		}
	}

	class Solution extends Element {
		private int[] combination;

		public Solution(int[] key, int weight, int value) {
			super (weight, value);
			this.combination = key;
		}

		@Override
		public String toString() {
			return "Solution{" +
							"combination=" + Arrays.toString(combination) +
							", weight=" + getWeight() +
							", value=" +getValue() +
							'}';
		}
	}


	/**
	 * Compute all possible solutions for the knapsack problem
	 * @return
	 */
	Map<int[], Element> solve ();

	/**
	 * Finds the (one of the) best solutions within all possible solutions for the knapsack problem
	 * @param map - return value of {@link #solve()}
	 * @return
	 */
	Solution findBest (Map<int[], Element> map);

}
