package algodat.searching;

import algodat.structure.tree.binary.IBinaryTree;

public interface IBinaryTreeSearch<V extends Comparable<V>> {

	boolean hasValue (V value, IBinaryTree<V> tree);

}
