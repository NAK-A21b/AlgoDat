package algodat;

public interface IBiggestCommonDivisor {

	/**
	 * Compute the biggest common divisor of the two numbers given
	 * @param m first number
	 * @param n second number
	 * @return biggest common divisor of m and n
	 */
	int solve(int m, int n);

}
