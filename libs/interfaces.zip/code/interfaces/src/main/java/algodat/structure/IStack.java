package algodat.structure;

public interface IStack<E> {

    /**
     * Lege das übergebene Element oben auf den Stack.
     * @param item das auf den Stack zu legende Element
     */
    void push(E item);

    /**
     * Entnehme das oberste Element vom Stack und gebe es zurück.
     * @return das oberste Element auf dem Stack, null wenn es kein solches Element gibt
     */
    E pop ();

    /**
     * Lese das oberste Element vom Stack und gebe es zurück. Das Element verbleibt auf dem Stack.
     * @return das oberste Element auf dem Stack, null wenn es kein solches Element gibt
     */
    E top ();

    /**
     * Überprüfe, ob der Stack Elemente enthält.
     * @return true, wenn der Stack mindestens ein Element enthält, ansonsten ({@link #size()} == 0) false
     */
    boolean isEmpty ();

    /**
     * Die Methode size liefert die Anzahl der auf dem Stack liegenden Elemente zurück.
     * @return Die Anzahl der Elemente auf dem Stack. Liefert 0, wenn {@link #isEmpty()} true liefert.
     */
    int size ();

}
