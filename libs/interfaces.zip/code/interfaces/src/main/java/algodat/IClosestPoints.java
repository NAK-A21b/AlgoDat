package algodat;

import java.util.List;

public interface IClosestPoints {

	/**
	 * A point in a 2-dimensional plane.
	 */
	class Point {
		private int x, y;

		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}

		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}
	}

	/**
	 * Search for the two closest points in a list of points given and return the indices of these.
	 * @param points - a list of points to the search the closest pair of points in
	 * @return indices of the closest points in points
	 */
	Point find(List<Point> points);

}
