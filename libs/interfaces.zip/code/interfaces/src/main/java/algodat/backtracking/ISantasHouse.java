package algodat.backtracking;

import algodat.structure.graph.IGraph;
import algodat.structure.graph.IVertex;

import java.util.List;
import java.util.Objects;

public interface ISantasHouse {

	class Path {
		IVertex<String> a;
		IVertex<String> b;

		public Path (IVertex<String> a, IVertex<String> b) {
			this.a = a;
			this.b = b;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;
			Path path = (Path) o;
			return (Objects.equals(a, path.a) && Objects.equals(b, path.b)) || (Objects.equals(b, path.a) && Objects.equals(a, path.b));
		}

		@Override
		public int hashCode() {
			return Objects.hash(a, b) + Objects.hash(b, a);
		}
	}

	/**
	 * A simple "Haus vom Nikolaus"
	 *   A
	 *  / \
	 *  B_C
	 *  | |
	 *  D_E
	 * @return
	 */
	static IGraph<String> createSimpleHouse(IGraph<String> graph) {

		IVertex<String> a = graph.addVertex("A");
		IVertex<String> b = graph.addVertex("B");
		IVertex<String> c = graph.addVertex("C");
		IVertex<String> d = graph.addVertex("D");
		IVertex<String> e = graph.addVertex("E");

		graph.addEdge(a, b);
		graph.addEdge(a, c);
		graph.addEdge(c, b);
		graph.addEdge(c, d);
		graph.addEdge(c, e);
		graph.addEdge(d, e);
		graph.addEdge(b, d);
		graph.addEdge(b, e);

		return graph;
	}

	/**
	 * A mirrored "Haus vom Nikolaus"
	 *   A
	 *  / \
	 *  B_C
	 *  | |
	 *  D_E
	 *  | |
	 *  F G
	 *  \ /
	 *   H
	 * @return
	 */
	static IGraph<String> createMirroredHouse(IGraph<String> graph) {

		IVertex<String> a = graph.addVertex("A");
		IVertex<String> b = graph.addVertex("B");
		IVertex<String> c = graph.addVertex("C");
		IVertex<String> d = graph.addVertex("D");
		IVertex<String> e = graph.addVertex("E");

		graph.addEdge(a, b);
		graph.addEdge(a, c);
		graph.addEdge(c, b);
		graph.addEdge(c, d);
		graph.addEdge(c, e);
		graph.addEdge(d, e);
		graph.addEdge(b, d);
		graph.addEdge(b, e);

		IVertex<String> f = graph.addVertex("F");
		IVertex<String> g = graph.addVertex("G");
		IVertex<String> h = graph.addVertex("H");

		graph.addEdge(h, f);
		graph.addEdge(h, g);
		graph.addEdge(f, g);
		graph.addEdge(f, d);
		graph.addEdge(f, e);
		graph.addEdge(g, e);
		graph.addEdge(g, d);

		return graph;
	}

	/**
	 * Find all possible solutions
	 * @param graph
	 * @return
	 */
	List<List<Path>> findSolutions (IGraph<String> graph);

}
