package algodat.structure.graph;

/**
 * @author himmelspach
 * @param <E>
 */
public interface IVisitor<E> {
	boolean visit (IVertex<E> v);
}
