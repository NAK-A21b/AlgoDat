package algodat.sorting;

/**
 * @author himmelspach
 * @param <E>
 */
public interface IPartition<E extends Comparable<E>> {

	/**
	 * Returns the element i in between borders l and r referencing the element from a to split the elements between
	 * l and r. The order of elements in array a might be modified by the method.
	 * @param a - the array of elements to find a suitable pivot element
	 * @param l - the left border of the range within a to start the search for the pivot element
	 * @param r - the right border of the range within a to end the seach for the pivot element
	 * @return the index of the pivot element
	 */
	int partition(E[] a, int l, int r);

}
