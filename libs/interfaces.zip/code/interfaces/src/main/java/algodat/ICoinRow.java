package algodat;

import java.util.List;

public interface ICoinRow {

	List<Integer> solveCoins(int[] row);

}
