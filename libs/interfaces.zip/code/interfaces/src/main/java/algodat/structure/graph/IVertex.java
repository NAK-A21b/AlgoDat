package algodat.structure.graph;

public interface IVertex<E> {

	E getValue();

}
