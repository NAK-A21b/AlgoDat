package algodat.sorting;

/**
 * Simple algodat.sorting interface (implementations sort passed array of comparable elements)
 *
 * @param <E> type of elements to be sorted
 * @author himmelspach
 */
public interface ISort<E extends Comparable<E>> {

	/**
	 * Swaps elements at position i and j in the array a
	 *
	 * @param a the array the elements at i and j shall be swapped
	 * @param i the index of the first element
	 * @param j the index of the second element
	 */
	public default void swap(E[] a, int i, int j) {
		E temp = a[i];
		a[i] = a[j];
		a[j] = temp;
	}

	/**
	 * Sort the array and return sorted array
	 *
	 * @param a - array to be sorted
	 * @return array with elements sorted
	 */
	E[] sort(E[] a);

}
